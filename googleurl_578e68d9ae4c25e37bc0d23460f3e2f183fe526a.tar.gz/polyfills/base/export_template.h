// Copyright (c) 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef POLYFILLS_BASE_EXPORT_TEMPLATE_H_
#define POLYFILLS_BASE_EXPORT_TEMPLATE_H_

#define EXPORT_TEMPLATE_DEFINE(export)
#define EXPORT_TEMPLATE_DECLARE(export)

#endif  /* POLYFILLS_BASE_EXPORT_TEMPLATE_H_ */
